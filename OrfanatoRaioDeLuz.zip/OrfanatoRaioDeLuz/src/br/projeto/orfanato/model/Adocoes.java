/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.projeto.orfanato.model;

/**
 *
 * @author maria
 */
public class Adocoes {
     private int id;
    private int idCrianca;
    private String nomeAdotante;
    private String endereco;
    private String telefone;
    private String status;
    private java.sql.Date dataInicio;
    private java.sql.Date dataConclusao;

    public Adocoes () {}

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public int getIdCrianca() { return idCrianca; }
    public void setIdCrianca(int idCrianca) { this.idCrianca = idCrianca; }

    public String getNomeAdotante() { return nomeAdotante; }
    public void setNomeAdotante(String nomeAdotante) { this.nomeAdotante = nomeAdotante; }

    public String getEndereco() { return endereco; }
    public void setEndereco(String endereco) { this.endereco = endereco; }

    public String getTelefone() { return telefone; }
    public void setTelefone(String telefone) { this.telefone = telefone; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public java.sql.Date getDataInicio() { return dataInicio; }
    public void setDataInicio(java.sql.Date dataInicio) { this.dataInicio = dataInicio; }

    public java.sql.Date getDataConclusao() { return dataConclusao; }
    public void setDataConclusao(java.sql.Date dataConclusao) { this.dataConclusao = dataConclusao; }
}
