/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.projeto.orfanato.model;

public class Saude {
      private int id;
    private int idCrianca;
    private java.sql.Date dataConsulta;
    private String medico;
    private String descricao;
    private String vacinas;
    private String medicamentos;

    public Saude() {}

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public int getIdCrianca() { return idCrianca; }
    public void setIdCrianca(int idCrianca) { this.idCrianca = idCrianca; }

    public java.sql.Date getDataConsulta() { return dataConsulta; }
    public void setDataConsulta(java.sql.Date dataConsulta) { this.dataConsulta = dataConsulta; }

    public String getMedico() { return medico; }
    public void setMedico(String medico) { this.medico = medico; }

    public String getDescricao() { return descricao; }
    public void setDescricao(String descricao) { this.descricao = descricao; }

    public String getVacinas() { return vacinas; }
    public void setVacinas(String vacinas) { this.vacinas = vacinas; }

    public String getMedicamentos() { return medicamentos; }
    public void setMedicamentos(String medicamentos) { this.medicamentos = medicamentos; }
}
