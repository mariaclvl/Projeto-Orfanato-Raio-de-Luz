/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.projeto.orfanato.model;

public class Educacao {
    private int id;
    private int idCrianca;
    private String escola;
    private String anoEscolar;
    private String notas;
    private String observacoes;

    public Educacao() {}

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public int getIdCrianca() { return idCrianca; }
    public void setIdCrianca(int idCrianca) { this.idCrianca = idCrianca; }

    public String getEscola() { return escola; }
    public void setEscola(String escola) { this.escola = escola; }

    public String getAnoEscolar() { return anoEscolar; }
    public void setAnoEscolar(String anoEscolar) { this.anoEscolar = anoEscolar; }

    public String getNotas() { return notas; }
    public void setNotas(String notas) { this.notas = notas; }

    public String getObservacoes() { return observacoes; }
    public void setObservacoes(String observacoes) { this.observacoes = observacoes; }
}
