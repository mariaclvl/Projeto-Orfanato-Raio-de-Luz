/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.projeto.orfanato.model;

public class Voluntarios {
     private int id;
    private String nome;
    private String documento;
    private String telefone;
    private String atividade;
    private java.sql.Date dataInicio;
    private java.sql.Date dataFim;

    public Voluntarios() {}

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getNome() { return nome; }
    public void setNome(String nome) { this.nome = nome; }

    public String getDocumento() { return documento; }
    public void setDocumento(String documento) { this.documento = documento; }

    public String getTelefone() { return telefone; }
    public void setTelefone(String telefone) { this.telefone = telefone; }

    public String getAtividade() { return atividade; }
    public void setAtividade(String atividade) { this.atividade = atividade; }

    public java.sql.Date getDataInicio() { return dataInicio; }
    public void setDataInicio(java.sql.Date dataInicio) { this.dataInicio = dataInicio; }

    public java.sql.Date getDataFim() { return dataFim; }
    public void setDataFim(java.sql.Date dataFim) { this.dataFim = dataFim; }
}
