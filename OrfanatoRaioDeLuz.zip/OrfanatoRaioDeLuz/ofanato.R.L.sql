-- CREATE DATABASE OrfanatoRLuz;
USE OrfanatoRLuz;
SELECT * FROM Criancas;
SELECT * FROM Funcionarios;
SELECT * FROM Voluntarios;
SELECT * FROM Adocoes;
SELECT * FROM Saude;
SELECT * FROM Educacao;
SELECT * FROM Financas;
SELECT * FROM Estoque;

CREATE TABLE Criancas (
    id_crianca INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    data_nascimento DATE NOT NULL,
    sexo ENUM('M','F','Outro') NOT NULL,
    estado_saude TEXT,
    escolaridade VARCHAR(100),
    data_entrada DATE NOT NULL,
    situacao_juridica VARCHAR(100),
    historico_familiar TEXT
);


CREATE TABLE Funcionarios (
    id_funcionario INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    cargo VARCHAR(50),
    telefone VARCHAR(20),
    email VARCHAR(100),
    data_contratacao DATE,
    turno ENUM('Manhã','Tarde','Noite')
);


CREATE TABLE Voluntarios (
    id_voluntario INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    documento VARCHAR(30),
    telefone VARCHAR(20),
    atividade VARCHAR(100),
    data_inicio DATE,
    data_fim DATE
);


CREATE TABLE Adocoes (
    id_adocao INT AUTO_INCREMENT PRIMARY KEY,
    id_crianca INT,
    nome_adotante VARCHAR(100) NOT NULL,
    endereco VARCHAR(150),
    telefone VARCHAR(20),
    status ENUM('Em andamento','Concluída','Negada') DEFAULT 'Em andamento',
    data_inicio DATE,
    data_conclusao DATE
);

CREATE TABLE Saude (
    id_registro INT AUTO_INCREMENT PRIMARY KEY,
    id_crianca INT,
    data_consulta DATE,
    medico VARCHAR(100),
    descricao TEXT,
    vacinas TEXT,
    medicamentos TEXT
);


CREATE TABLE Educacao (
    id_registro INT AUTO_INCREMENT PRIMARY KEY,
    id_crianca INT,
    escola VARCHAR(100),
    ano_escolar VARCHAR(50),
    notas TEXT,
    observacoes TEXT
);


CREATE TABLE Financas (
    id_financa INT AUTO_INCREMENT PRIMARY KEY,
    tipo ENUM('Entrada','Saída') NOT NULL,
    valor DECIMAL(10,2) NOT NULL,
    origem VARCHAR(100),
    finalidade VARCHAR(100),
    data_movimentacao DATE NOT NULL
);


CREATE TABLE Estoque (
    id_item INT AUTO_INCREMENT PRIMARY KEY,
    nome_item VARCHAR(100) NOT NULL,
    tipo ENUM('Alimento','Roupa','Material Escolar','Remédio','Outro') NOT NULL,
    quantidade INT DEFAULT 0,
    validade DATE,
    local_armazenamento VARCHAR(100)
);



ALTER TABLE Saude
ADD CONSTRAINT fk_saude_crianca
FOREIGN KEY (id_crianca) REFERENCES Criancas(id_crianca);

ALTER TABLE Educacao
ADD CONSTRAINT fk_educacao_crianca
FOREIGN KEY (id_crianca) REFERENCES Criancas(id_crianca);

ALTER TABLE Adocoes
ADD CONSTRAINT fk_adocao_crianca
FOREIGN KEY (id_crianca) REFERENCES Criancas(id_crianca);

ALTER TABLE Financas
ADD COLUMN id_funcionario INT,
ADD CONSTRAINT fk_financas_funcionario
FOREIGN KEY (id_funcionario) REFERENCES Funcionarios(id_funcionario);

ALTER TABLE Estoque
ADD COLUMN id_funcionario INT,
ADD CONSTRAINT fk_estoque_funcionario
FOREIGN KEY (id_funcionario) REFERENCES Funcionarios(id_funcionario);

ALTER TABLE Voluntarios
ADD COLUMN id_funcionario INT,
ADD CONSTRAINT fk_voluntario_funcionario
FOREIGN KEY (id_funcionario) REFERENCES Funcionarios(id_funcionario);